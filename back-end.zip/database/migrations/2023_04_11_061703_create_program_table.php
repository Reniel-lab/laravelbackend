<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('program', function (Blueprint $table) {
            $table->id();
            $table->string('title')->nullable();
            $table->date('start_date')->nullable();
            $table->date('end_date')->nullable();
            $table->string('place')->nullable();
            $table->string('details')->nullable();
            $table->string('leader')->nullable();
            $table->string('member')->nullable();
            $table->string('participant')->nullable();
            $table->string('partner')->nullable();
            $table->boolean('archive')->default(false);
            $table->string('status')->default('ongoing');
            $table->timestamp('cert_id')->nullable();
            $table->string('invitation')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('program');
    }
};