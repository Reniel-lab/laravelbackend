<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('program', function (Blueprint $table) {
            $table->string('program_flow')->nullable();

            $table->unsignedBigInteger('leader')->nullable()->change();
            $table->foreign('leader')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
            $table->unsignedBigInteger('member')->nullable()->change();
            $table->foreign('member')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
            $table->unsignedBigInteger('partner')->nullable()->change();
            $table->foreign('partner')->references('id')->on('partner')->onDelete('cascade')->onUpdate('cascade');
            $table->unsignedBigInteger('cert_id')->nullable()->change();
            $table->foreign('cert_id')->references('id')->on('documents')->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('program', function (Blueprint $table) {
            $table->dropColumn(['program_flow']);
        });
    }
};