<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('moa', function (Blueprint $table) {
            $table->id();
            $table->string('filename')->nullable();
            $table->string('mime_type')->nullable();
            $table->string('data')->nullable();
            // $table->unsignedBigInteger('partnerID')->nullable();
            // $table->foreign('partnerID')->references('id')->on('partner')->onDelete('cascade')->onUpdate('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('moa');
    }
};