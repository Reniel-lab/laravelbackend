<?php

use App\Http\Controllers\AuthController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::group([

    'middleware' => 'api',

], function ($router) {

    Route::get('profile/{id}', 'App\Http\Controllers\AuthController@profiledata');
    Route::get('programbyid/{id}', 'App\Http\Controllers\AuthController@getProgrambyID');
    Route::get('programbyidfinish/{id}', 'App\Http\Controllers\AuthController@getProgrambyIDfinish');
    Route::get('programgraph', 'App\Http\Controllers\AuthController@getProgramGraph');
    Route::get('program', 'App\Http\Controllers\AuthController@getProgram');
    Route::get('partnersremind', 'App\Http\Controllers\AuthController@getPartnersReminder');
    Route::get('doneprogram', 'App\Http\Controllers\AuthController@getDoneProgram');
    Route::get('allprogram/{status}', 'App\Http\Controllers\AuthController@getAllProgram');
    Route::get('allpartners/{status}', 'App\Http\Controllers\AuthController@getAllPartners');
    Route::get('pending', 'App\Http\Controllers\AuthController@getPending');
    Route::get('getdelaccount', 'App\Http\Controllers\AuthController@getDelAccount');
    Route::get('approved', 'App\Http\Controllers\AuthController@getApproved');
    Route::get('partner', 'App\Http\Controllers\AuthController@getPartner');
    Route::get('getalldocu/{ids}', 'App\Http\Controllers\AuthController@getAllDocu');
    Route::get('partnerhistory/{id}', 'App\Http\Controllers\AuthController@getPartnerHistory');
    Route::get('deletedpartner', 'App\Http\Controllers\AuthController@getDeletedPartner');
    Route::get('delprogram', 'App\Http\Controllers\AuthController@getDelProgram');
    Route::get('expartner', 'App\Http\Controllers\AuthController@getXPartner');
    Route::get('userdropdown', 'App\Http\Controllers\AuthController@userDropDown');
    Route::get('getoneprogram/{id}', 'App\Http\Controllers\AuthController@getOneProgram');
    Route::get('getonepartner/{id}', 'App\Http\Controllers\AuthController@getOnePartner');
    Route::get('getpicture/{id}', 'App\Http\Controllers\AuthController@getPicture');
    Route::get('getlogo/{id}', 'App\Http\Controllers\AuthController@getLogo');
    Route::get('getfile/{id}', 'App\Http\Controllers\AuthController@getFile');
    Route::post('login', 'App\Http\Controllers\AuthController@login');
    // Route::post('signup', 'App\Http\Controllers\AuthController@signup');
    Route::post('/signup', [AuthController::class, 'signup']);
    Route::post('/addprogram', [AuthController::class, 'addProgram']);
    Route::post('/addpartner', [AuthController::class, 'addPartner']);
    Route::post('partnerupdate/{id}', 'App\Http\Controllers\AuthController@updatePartner');
    Route::post('contentupdate/{id}', 'App\Http\Controllers\AuthController@contentUpdate');
    Route::post('picture/{id}', 'App\Http\Controllers\AuthController@changePic');
    Route::post('logo', 'App\Http\Controllers\AuthController@changeLogo');
    Route::post('acceptaccount/{id}', 'App\Http\Controllers\AuthController@acceptAccount');
    Route::post('logout', 'App\Http\Controllers\AuthController@logout');
    Route::post('sendemail/{email}', 'App\Http\Controllers\AuthController@sendEmail');
    Route::post('verify/{otp}/{code}', 'App\Http\Controllers\AuthController@verify');
    Route::post('programdelete/{id}', 'App\Http\Controllers\AuthController@programDelete');
    Route::post('programrestore/{id}', 'App\Http\Controllers\AuthController@programRestore');
    Route::post('partnerrestore/{id}', 'App\Http\Controllers\AuthController@partnerRestore');
    Route::post('deleteaccount/{id}', 'App\Http\Controllers\AuthController@accountDelete');
    Route::post('deleteactivepartner/{id}', 'App\Http\Controllers\AuthController@activePartnerDelete');
    Route::post('accountrestore/{id}', 'App\Http\Controllers\AuthController@accountRestore');
    Route::post('partnerrenew/{id}', 'App\Http\Controllers\AuthController@renewPartner');
    Route::post('programupdate/{id}', 'App\Http\Controllers\AuthController@updateProgram');
    Route::put('userupdate/{id}', 'App\Http\Controllers\AuthController@updateUser');
    Route::put('passwordupdate/{id}', 'App\Http\Controllers\AuthController@updatePass');
    Route::put('passwordreset/{id}', 'App\Http\Controllers\AuthController@restPass');
    Route::put('changepassword/{id}', 'App\Http\Controllers\AuthController@changePass');

});