<?php echo e($slot); ?>

<?php /**PATH C:\Users\Bernardino\Desktop\angular\ext-JM\extension-office-management-systemV2\back-end\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>