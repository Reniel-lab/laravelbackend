<?php echo e($slot); ?>

<?php /**PATH C:\Users\Bernardino\Desktop\angular\extension-office-management-system\back-end\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>