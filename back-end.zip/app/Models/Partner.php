<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Partner extends Model
{
    use HasFactory;
    protected $table = 'partner';
    protected $fillable = [
        'id',
        'name',
        'start_date',
        'end_date',
        'address',
        'contact_person',
        'contact_no',
        'moa_file',
    ];
}