<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Program extends Model
{
    use HasFactory;
    protected $table = 'program';
    protected $fillable = [
        'id',
        'title',
        'start_date',
        'end_date',
        'place',
        'details',
        'leader',
        'member',
        'participant',
        'partner',
        'cert_id',
        'invitation',
        'status',
        'archive',
    ];
}