<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Verify extends Model
{
    use HasFactory;
    protected $table = 'verify';
    protected $fillable = [
        'user_id',
        'v_code',
        'expired',
    ];
}