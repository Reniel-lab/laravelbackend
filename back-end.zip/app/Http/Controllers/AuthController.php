<?php

namespace App\Http\Controllers;

use App\Models\Partner;
use App\Models\Content;
use App\Models\Documents;
use App\Models\Program;
use App\Models\Moa;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Tymon\JWTAuth\Facades\JWTAuth;
use App\Models\User;
use App\Models\Verify;
use App\Notifications\signUpEmailVerify;
use Illuminate\Auth\Events\Verified;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use DateTime;



class AuthController extends Controller
{
    public function signup(Request $request)
    {
        // dd($request->all());
        $validator = Validator::make($request->all(), [
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'middle_name' => 'nullable|string|max:255',
            'suffix' => 'nullable|string|max:255',
            'mobile' => 'nullable|string|max:255',
            'bday' => 'nullable|string|max:255',
            'address' => 'nullable|string|max:255',
            'gender' => 'nullable|string|max:255',
            'role' => 'nullable|string|max:255',
            'email' => 'required|email|unique:users|max:255',
            'archive' => 'nullable|boolean',
            'status' => 'nullable|string|max:255',
            'password' => 'required|string|min:8',
            'picture' => 'nullable|string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }
    
        $user = new User;
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->email = $request->email;
        $user->password = Hash::make($request->password);
        $user->save();

        // $userid=User::where('email',$request->email)->get()->first();

        // $code=$this->generateVerificationCode();

        // $expires_at = now('Asia/Manila')->addMinutes(5);
        // Verify::create([
        //     'user_id' => $userid->id,
        //     'v_code' => $code,
        //     'expired' => $expires_at 
        // ]);

        // $user->notify(new signUpEmailVerify($code));
    
        $token = JWTAuth::fromUser($user);
    
        return response()->json([
            'success' => true,
            'token' => $token,
            'user' => $user
        ], 201);
    }

    public function login(Request $request)
{
    $credentials = $request->only('email', 'password');
    $validator = Validator::make($credentials,[
        'email' => 'required||email||',
        'password' => 'required|',
    ]);

    if($validator->fails()){
        return response()->json([
            'success' => false,
            'message' => 'Invalid credentials',
            'error' => $validator ->errors(),
        ],401);
    }

    if (Auth::attempt($credentials)) {
        $user = Auth::user();
        if ("pending"== $user->status) {
            return response()->json(['error' => 'Your Account is still Pending please contact the Admin','success' => false,'pending' => true]);
        }
        $token = JWTAuth::fromUser($user);
        return response()->json(['token' => $token,'success' => true,'message' => 'Login Successfully', 'user' => $user]);
    } else {
        return response()->json(['error' => 'Invalid credentials','success' => false,'pending' => false]);
    }
}
// public function profiledata($email)
//     {
        
//     }

    public function profiledata($id){
        $user = DB::table('users')->where('id', $id)->first();
        return response()->json($user);
    }

    public function changePic(Request $credentials,$id){
        // dd($credentials);
        // $credentials = $request->only('picture');
        //if ($credentials->hasfile('picture')) {
        //     dd('dsfdsf');
        // }
            $image = $credentials->file('picture');
            // dd($image);
            $filename = time() . '.' . $image->getClientOriginalName();
            // $path = public_path('uploads/' . $filename);
            $image->move(public_path('picture'), $filename);
            // $user = DB::table('users')->where('id', $id)->update([
            //     'picture' => $filename
            // ]);
            $user = User::find($id);
            if (!$user) {
                return response()->json(['error' => 'User not found'], 404);
            }
            $user->picture =$filename;
            $user->save();
            // Image::make($image->getRealPath())->save($path);
            return response()->json(['success' =>true,'user'=>$user]);
       // }
        // return response()->json(['success' => false, 'error' => $credentials->hasFile('picture')]);
    }

    public function changeLogo(Request $credentials){
       
            $image = $credentials->file('logo');
            $filename = time() . '.' . $image->getClientOriginalName();
           // $image->move(public_path('picture'), $filename);
            $path = $image->storeAs('Logo', $filename, 'public');
            $logo = Content::find(1);
            if (!$logo) {
                return response()->json(['error' => 'User not found'], 404);
            }
            $logo->logo =$filename;
            $logo->logo_path ='storage/' . $path;
            $logo->save();
            return response()->json(['success' =>true,'user'=>$logo]);
    }

    public function getPicture($id){
        $user = User::find($id);
        if ($user) {
            $filename = $user->picture;
            // $pathToImages = public_path('picture');
            // $filePath = $pathToImages . DIRECTORY_SEPARATOR . $filename;
            // $imageUrl = asset(`picture/$filename`);
            // $path = "public/picture/{$filename}";
            // $url = Storage::url($path);
            // $file = Storage::disk('public')->get($filename);
            // $response = response($file, 200, [
            //     'Content-Type' => 'image/jpg',
            //     'Content-Disposition' => 'inline'
            // ]);
            // return $response;
            return response()->json(['path' => $filename]);
        } else {
            return response()->json(['error' => 'User not found'], 404);
        }
    }

    public function getLogo($id){
        $logo = Content::find($id);
        if ($logo) {
            $path = $logo->logo_path;
            return response()->json(['logo' => $logo,'path' => $path]);
        } else {
            return response()->json(['error' => 'User not found'], 404);
        }
    }

    public function updateUser($id, Request $request){
        $user = DB::table('users')->where('id', $id)->update([
            'first_name' => $request->input('first_name'),
            'middle_name' => $request->input('middle_name'),
            'last_name' => $request->input('last_name'),
            'suffix' => $request->input('suffix'),
            'email' => $request->input('email'),
            'password' => $request->input('password'),
            'mobile' => $request->input('mobile'),
            'bday' => $request->input('bday'),
            'address' => $request->input('address'),
            'gender' => $request->input('gender'),
            'role' => $request->input('role'),
            'archive' => $request->input('archive'),
            'status' => $request->input('status'),
            'archive' => $request->input('archive'),

        ]);
        return response()->json($user);
    }

    public function addProgram(Request $request){
        $docu_id='';
        if ($request->file('files')){
            $request->validate(['files[]' => 'mimetypes:application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document|max:10000']);

    
        $files = $request->file('files');
        if (!is_array($files)) {
            $files = [$files];
        }
        foreach ($files as $file) {
            $fileName = time().'_'.$file->getClientOriginalName();
            $path = $file->storeAs('Files', $fileName, 'public');
            $fileModel = new Documents;
            $fileModel->docu_name = $fileName;
            $fileModel->mime_type = $file->getClientMimeType();
            $fileModel->location = 'storage/' . $path;
            $fileModel->save();
            $docu_id=$docu_id.$fileModel->id.',';
        }
    }
        $leader=$request->input('leader');
        $member=$request->input('member');
        $partner= $request->input('partner');
        if (!is_array($leader)) {
            $leader = [$leader];
        }
        if (!is_array($member)) {
            $member = [$member];
        }
        if (!is_array($partner)) {
            $partner = [$partner];
        }

        $program = new Program;
        $program->title = $request->title;
        $program->start_date = $request->start_date;
        $program->end_date = $request->end_date;
        $program->place = $request->place;
        $program->leader = implode(",", $request->leader);
       $program->member = implode(",", $request->member);
       $program->partner = implode(",", $request->partner);
       $program->program_flow = $request->program_flow;
       $program->participant = $request->participant;
       $program->details = $request->details;
       $program->add_details = $request->add_details;
       $program->cert_id = $docu_id;
        $program->save();
    }

    public function addPartner(Request $request){

        $request->validate(['moa_file' => 'mimetypes:application/pdf,application/
        msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document|max:10000']);
         
        $file = $request->file('moa_file');
        $fileName = time().'_'.$file->getClientOriginalName();
      //  $file->move(public_path('Moa_files'), $fileName);
      //  $filePath ="Moa_files/".$fileName;

        
        $filePath = $file->storeAs('Moa_files', $fileName, 'public');
        // $fileModel->name = time().'_'.$request->file->getClientOriginalName();
        // $fileModel->file_path = '/storage/' . $filePath;
       
 
        $document = new Moa;
        $document->filename = $fileName;
        $document->mime_type = $file->getClientMimeType();
        $document->data = 'storage/' . $filePath;
        $document->save();


        $partner = new Partner;
        $partner->name = $request->name;
        $partner->start_date = $request->start_date;
        $partner->end_date = $request->end_date;
        $partner->address = $request->address;
        $partner->contact_person = $request->contact_person;
        $partner->contact_no = $request->contact_no;
        $partner->moa_file = $document->id;
        $partner->save();
    }
    public function renewPartner($id,Request $request){

        $request->validate(['moa_file' => 'mimetypes:application/pdf,application/
        msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document|max:10000']);
         
        $file = $request->file('moa_file');
        $fileName = time().'_'.$file->getClientOriginalName();
        $file->move(public_path('Moa_files'), $fileName);
        $filePath ="Moa_files/".$fileName;
 
        $document = new Moa;
        $document->filename = $fileName;
        $document->mime_type = $file->getClientMimeType();
        $document->data = $filePath;
        $document->save();

        $partner = new Partner;
        $partner->name = $request->name;
        $partner->start_date = $request->start_date;
        $partner->end_date = $request->end_date;
        $partner->address = $request->address;
        $partner->contact_person = $request->contact_person;
        $partner->contact_no = $request->contact_no;
        $partner->moa_file = $document->id;
        $partner->save();

        $data = Partner::find($id);
        if (!$data) {
            return response()->json(['error' => 'User not found'], 404);
        }
        $data->status =  $partner->id;
        $data->save();
        
        return response()->json(['new' => $partner,'updated' =>$data]);
    }

    public function getProgram(){

        $programs = Program::where([['status', 'upcoming'],['archive', 0]])->get();
        
        foreach ($programs as $program) {
            $expiryDate = new DateTime($program->end_date);
            $currentDate = now();
            $diff = $expiryDate->diff($currentDate);
            
            if ($diff->format('%R') == '-') {
                // Product has expired
                // $partner->status = "active";
                // $partner->save();
                continue;
            } else{
                $program->status = "finished";
                $program->save();
            }
        }
        $data = DB::table('program')->where([['status', 'upcoming'],['archive', 0]])->get();

        //$data = DB::table('program')->where('archive', 0)->get();
        return response()->json($data);
    }

    public function getProgrambyID($id){
        $programs = Program::where([['status', 'upcoming'],['archive', 0]])->get();
        
        foreach ($programs as $program) {
            $expiryDate = new DateTime($program->end_date);
            $currentDate = now();
            $diff = $expiryDate->diff($currentDate);
            
            if ($diff->format('%R') == '-') {
                // Product has expired
                // $partner->status = "active";
                // $partner->save();
                continue;
            } else{
                $program->status = "finished";
                $program->save();
            }
        }
        $data = DB::table('program')
        ->where('status', 'upcoming')
        ->where(function ($query) use ($id) {
            $query->where('leader', 'like', "%$id%")
                  ->orWhere('member', 'like', "%$id%");
        })
        ->get();
        return response()->json($data);
    }

    public function getProgrambyIDfinish($id){
        $data = DB::table('program')
        ->where('status', 'finished')
        ->where(function ($query) use ($id) {
            $query->where('leader', 'like', "%$id%")
                  ->orWhere('member', 'like', "%$id%");
        })
        ->get();
        return response()->json($data);
    }

    public function getProgramGraph(){
        $currentYear = now()->year;
        $jan = DB::table('program')
        ->whereBetween(DB::raw('DATE(start_date)'), [$currentYear.'-01-01', $currentYear.'-01-31'])
        ->get();
        $jannumRows = count($jan);
        $feb = DB::table('program')
        ->whereBetween(DB::raw('DATE(start_date)'), [$currentYear.'-02-01', $currentYear.'-02-28'])
        ->get();
        $febnumRows = count($feb);
        $march = DB::table('program')
        ->whereBetween(DB::raw('DATE(start_date)'), [$currentYear.'-03-01', $currentYear.'-03-31'])
        ->get();
        $marchnumRows = count($march);
        $april = DB::table('program')
        ->whereBetween(DB::raw('DATE(start_date)'), [$currentYear.'-04-01', $currentYear.'-04-30'])
        ->get();
        $aprilnumRows = count($april);
        $may = DB::table('program')
        ->whereBetween(DB::raw('DATE(start_date)'), [$currentYear.'-05-01', $currentYear.'-05-31'])
        ->get();
        $maynumRows = count($may);
        $june = DB::table('program')
        ->whereBetween(DB::raw('DATE(start_date)'), [$currentYear.'-06-01', $currentYear.'-06-30'])
        ->get();
        $junenumRows = count($june);
        $july = DB::table('program')
        ->whereBetween(DB::raw('DATE(start_date)'), [$currentYear.'-07-01', $currentYear.'-07-31'])
        ->get();
        $julynumRows = count($july);
        $aug = DB::table('program')
        ->whereBetween(DB::raw('DATE(start_date)'), [$currentYear.'-08-01', $currentYear.'-08-31'])
        ->get();
        $augnumRows = count($aug);
        $sept = DB::table('program')
        ->whereBetween(DB::raw('DATE(start_date)'), [$currentYear.'-09-01', $currentYear.'-09-30'])
        ->get();
        $septnumRows = count($sept);
        $oct = DB::table('program')
        ->whereBetween(DB::raw('DATE(start_date)'), [$currentYear.'-10-01', $currentYear.'-10-31'])
        ->get();
        $octnumRows = count($oct);
        $nov = DB::table('program')
        ->whereBetween(DB::raw('DATE(start_date)'), [$currentYear.'-11-01', $currentYear.'-11-30'])
        ->get();
        $novnumRows = count($nov);
        $dec = DB::table('program')
        ->whereBetween(DB::raw('DATE(start_date)'), [$currentYear.'-12-01', $currentYear.'-12-31'])
        ->get();
        $decnumRows = count($dec);

        $upcoming = DB::table('program')->where([['status', 'upcoming'],['archive', 0]])->get();
        $upnumRows = count($upcoming);
        $finished = DB::table('program')->where([['status', 'finished'],['archive', 0]])->get();
        $finnumRows = count($finished);

        return response()->json(['jan'=>$jannumRows,'feb'=>$febnumRows,'march'=>$marchnumRows,'april'=>$aprilnumRows,'may'=>$maynumRows,
        'june'=>$junenumRows,'july'=>$julynumRows,'aug'=>$augnumRows,'sept'=>$septnumRows,'oct'=>$octnumRows,
        'nov'=>$novnumRows,'dec'=>$decnumRows,'upcoming'=>$upnumRows,'finished'=>$finnumRows]);
    }

    public function getDoneProgram(){
        $data = DB::table('program')->where([['status', 'finished'],['archive', 0]])->get();

        //$data = DB::table('program')->where('archive', 0)->get();
        return response()->json($data);
    }

    public function getPartnersReminder(){
        $partners = DB::table('partner')
        ->whereRaw('DATE_ADD(end_date, INTERVAL YEAR(CURDATE())-YEAR(end_date) YEAR) BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)')
        ->get();
        $faculty = DB::table('users')->where([['status', 'approved'],['archive', 1]])->get();
        $facnumRows = count($faculty);
        $numpartner = DB::table('partner')
        ->where([['status', 'active'], ['archive', 1]])
        ->orWhere([['status', 'expired']])
        ->get();
        $partnumRows = count($numpartner);
        $program = DB::table('program')->where([['archive', 0]])->get();
        $prognumRows = count($program);
        return response()->json(['partners' =>$partners,'faculty' =>$facnumRows,'partnumRows' =>$partnumRows,'prognumRows' =>$prognumRows]);
    }

    public function getallProgram($status){
        //$data = DB::table('program')->where([['status', $status],['archive', 0]])->get();
        $data = DB::table('program')
        ->join('partner', 'program.partner', '=', 'partner.id')
        ->where('program.status', '=', $status)
        ->where('program.archive', '=', 0)
        ->get();
        //$data = DB::table('program')->where('archive', 0)->get();
        return response()->json($data);
    }

    public function getallPartners($status){
        $data = DB::table('partner')->where([['status', $status],['archive', 1]])->get();
        return response()->json($data);
    }

    public function getPending(){
        $data = DB::table('users')->where([['status', 'pending'],['archive', 1]])->get();
        return response()->json($data);
    }

    public function userDropDown(){
        
        $data = DB::table('users')
        ->select('id', DB::raw("CONCAT_WS(' ', first_name, 
            CASE 
                WHEN LOCATE(' ', middle_name) = 0 THEN SUBSTRING(middle_name, 1, 1)
                ELSE CONCAT(SUBSTRING(middle_name, 1, 1), '.', SUBSTRING(SUBSTRING_INDEX(middle_name, ' ', -1), 1, 1), '.')
            END,
            last_name, suffix) AS full_name"))
        ->where('status', '=', 'approved')
        ->where('archive', '=', 1)
        //->where('role', '=', 'faculty')
        ->get();
    
    
    
        return response()->json($data);
    }

    public function getDelAccount(){
        $data = DB::table('users')->where([['archive', 0]])->get();
        return response()->json($data);
    }

    public function getDelProgram(){
        $data = DB::table('program')->where('archive', 1)->get();
        return response()->json($data);
    }

    public function getAllDocu($ids){
       // dd($ids);
       if(!isset($ids)){
        $data = DB::table('documents')->whereRaw('id IN ('.$ids.')')
        ->get();
    }else{
        $data='';
    }
        return response()->json($data);
    }

    public function getApproved(){
        $data = DB::table('users')->where([['status', 'approved'],['archive', 1],['role','faculty']])->get();
        return response()->json($data);
    }

    public function getPartnerHistory($id){
        // $data = DB::table('partner')->where('id', $id)->first();
        // $data1 = DB::table('partner')->where('status', $id)->get();
        // $merged = collect($data)->merge($data1);
        
        // $data = DB::table('partner')
        // ->where('partner.id', $id)
        // ->union(DB::table('partner')
        //         ->where('status', $id)
        // )
        // ->get();

        $data = DB::table('partner')
        ->join('moa', 'moa.id', '=', 'partner.moa_file')
        ->where('partner.id', '=', $id)
        ->select('*')
        ->union(
            DB::table('partner')
                ->join('moa', 'moa.id', '=', 'partner.moa_file')
                ->where('partner.status', '=', $id)
                ->select('*')
        )
        ->get();

        return response()->json($data);
    }

    public function getPartner(){
         $partners = Partner::where([['status', 'active'],['archive', 1]])->get();
        
        foreach ($partners as $partner) {
            $expiryDate = new DateTime($partner->end_date);
            $currentDate = now();
            $diff = $expiryDate->diff($currentDate);
            
            if ($diff->format('%R') == '-') {
                // Product has expired
                // $partner->status = "active";
                // $partner->save();
                continue;
            } else{
                $partner->status = "expired";
                $partner->save();
            }
        }
        $data = DB::table('partner')->where([['status', 'active'],['archive', 1]])->get();
        return response()->json($data);
    }

    public function getXPartner(){
        $data = DB::table('partner')->where([['status', 'expired'],['archive', 1]])->get();
        return response()->json($data);
    }

    public function getDeletedPartner(){
        $data = DB::table('partner')->where([['archive', 0]])->get();
        return response()->json($data);
    }

    public function getOneProgram($id){
        $data = DB::table('program')
        ->where('program.id', $id)
        ->first();
        $leader = $data->leader;
        $member = $data->member;
        $partner = $data->partner;
        $documents =$data->cert_id;
        $data4='';
        if($documents){ 
            $documents = substr($documents, 0, -1);
            $data4 = DB::table('documents')->select('location','docu_name','id')
            ->whereRaw('id IN ('.$documents.')')
            ->get(); 
        }
       
        $data1 = DB::table('users')
        ->select('id', DB::raw("CONCAT_WS(' ', first_name, 
        CASE 
            WHEN LOCATE(' ', middle_name) = 0 THEN SUBSTRING(middle_name, 1, 1)
            ELSE CONCAT(SUBSTRING(middle_name, 1, 1), '.', SUBSTRING(SUBSTRING_INDEX(middle_name, ' ', -1), 1, 1), '.')
        END,
        last_name, suffix) AS full_name"))
        ->whereRaw('id IN ('.$leader.')')
        ->get();

        $data2 = DB::table('users')
        ->select('id', DB::raw("CONCAT_WS(' ', first_name, 
        CASE 
            WHEN LOCATE(' ', middle_name) = 0 THEN SUBSTRING(middle_name, 1, 1)
            ELSE CONCAT(SUBSTRING(middle_name, 1, 1), '.', SUBSTRING(SUBSTRING_INDEX(middle_name, ' ', -1), 1, 1), '.')
        END,
        last_name, suffix) AS full_name"))
        ->whereRaw('id IN ('.$member.')')
        ->get();

        $data3 = DB::table('partner')->select('id','name')
        ->where('partner.id', $partner)
        ->get();

        

        return response()->json(['user'=>$data,'leader'=>$data1,'member'=>$data2,'partner'=>$data3,'documents'=>$data4]);
    }

    public function getFile($id){
        $data = DB::table('moa')->where('id', $id)->first();
        return response($data->data);
    // ->header('Content-Type', $data->mime_type)
    // ->header('Content-Disposition', 'attachment; filename="'.$data->filename.'"');

        // return response()->json($data);
    }

    public function getOnePartner($id){
        $data = DB::table('partner')->where('id', $id)->first();
        // //$data = Partner::with('moa')->find($id);
if($data->moa_file){
        $data = DB::table('partner')
        ->join('moa','moa.id','=','partner.moa_file')
        ->where('partner.id', $id)
        ->first();
        return response()->json($data);
    }
        else{
            return response()->json($data);
        }
    }

    public function updateProgram($id, Request $request){
        $docu_id='';
    
        if ($request->file('files')){
            $request->validate(['files[]' => 'mimetypes:application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document|max:10000']);

    
        $files = $request->file('files');
        if (!is_array($files)) {
            $files = [$files];
        }
        foreach ($files as $file) {
            $fileName = time().'_'.$file->getClientOriginalName();
            $path = $file->storeAs('Files', $fileName, 'public');
            $fileModel = new Documents;
            $fileModel->docu_name = $fileName;
            $fileModel->mime_type = $file->getClientMimeType();
            $fileModel->location = 'storage/' . $path;
            $fileModel->save();
            $docu_id=$docu_id.$fileModel->id.',';
        }
        $data1 = DB::table('program')->select('cert_id')->where([['id', $id]])->first();
        $docu_id = $data1->cert_id.$docu_id;
    }else{
        $documents=$request->input('documents');
        if(!$documents=='false'){
        $documents=$request->input('documents');
        if (!is_array($documents)) {
            $documents = [$documents];
        }
        $docu_id=$docu_id.implode(",", $request->input('documents')).',';
    }
    }
        $leader=$request->input('leader');
        $member=$request->input('member');
        $partner= $request->input('partner');
        if (!is_array($leader)) {
            $leader = [$leader];
        }
        if (!is_array($member)) {
            $member = [$member];
        }
        if (!is_array($partner)) {
            $partner = [$partner];
        }

        $data = DB::table('program')->where('id', $id)->update([
            'title' => $request->input('title'),
            'start_date' => $request->input('start_date'),
            'end_date' => $request->input('end_date'),
            'place' => $request->input('place'),
            'details' => $request->input('details'),
            'leader' => implode(",", $request->input('leader')),
            'member' => implode(",", $request->input('member')),
            'participant' => $request->input('participant'),
            'partner' => implode(",", $request->input('partner')),
            'program_flow' => $request->input('program_flow'),
            'add_details' => $request->input('add_details'),
            'cert_id' => $docu_id,
            
        ]);
        return response()->json($data);
    }

    public function updatePartner(Request $request,$id){

        $data = Partner::find($id);
        if (!$data) {
            return response()->json(['error' => 'User not found'], 404);
        }
        $data->name =$request->input('name');
        $data->address =$request->input('address');
        $data->contact_person =$request->input('contact_person');
        $data->contact_no =$request->input('contact_no');
        // $data->moa_file =$document->id;
        $data->save();

        //$request->validate(['moa_file' => 'required|mimetypes:application/pdf,application/msword|max:10000']);
          //required|mimetypes:application/pdf,application/msword|max:10000
 //         $file = $request->file('moa_file');
            // $filePath = $file->store('public/MOA_files');

 //           $fileName = time().'_'.$file->getClientOriginalName();
            // $filePath = $file->storeAs('Moa_files', $fileName, 'public');
 //           $file->move(public_path('Moa_files'), $fileName);
 //           $filePath ="Moa_files/".$fileName;
            // $fileModel->name = time().'_'.$request->file->getClientOriginalName();
            // $fileModel->file_path = '/storage/' . $filePath;
            // $fileContents = file_get_contents(storage_path('app/'.$filePath));

        // $document = Moa::find($data->moa_file);
        // $document->filename = $fileName;
        // $document->mime_type = $file->getClientMimeType();
        // $document->data = $filePath;
        // $document->save();

        return response()->json($data);
    }

    public function contentUpdate(Request $request,$id){
        $data = Content::find($id);
        if (!$data) {
            return response()->json(['error' => 'User not found'], 404);
        }
        $data->mission =$request->input('mission');
        $data->vision =$request->input('vision');
        $data->save();

        return response()->json($data);
    }

    public function updatePass($id, Request $request){

        $validatedData = $request->validate([
            'old_password' => 'required|string|min:8',
            'password' => 'required|string|min:8|confirmed',
        ]);
        $user = User::find($id);
        if (!$user) {
            return response()->json(['error' => 'User not found'], 404);
        }
        if (!Hash::check($request->old_password, $user->password)) {
            return response()->json(['error' => 'Incorrect current password'], 401);
        }
        $user->password = Hash::make($request->password);
         $user->save();
         return response()->json(['message' => 'Password updated successfully'], 200);
    }

    public function acceptAccount($id, Request $request){
       
        $user = User::find($id);
        if (!$user) {
            return response()->json(['error' => 'User not found'], 404);
        }
        $user->status = "approved";
         $user->save();
         return response()->json(['message' => 'User successfully updated', 'user' =>$user], 200);
    }

    public function programDelete($id, Request $request){
       
        $program = Program::find($id);
        if (!$program) {
            return response()->json(['error' => 'Program not found'], 404);
        }
        $program->archive = 1;
         $program->save();
         return response()->json(['message' => 'User successfully updated', 'user' =>$program], 200);
    }

    public function programRestore($id, Request $request){
       
        $program = Program::find($id);
        if (!$program) {
            return response()->json(['error' => 'Program not found'], 404);
        }
        $program->archive = 0;
         $program->save();
         return response()->json(['message' => 'Program successfully updated', 'program' =>$program], 200);
    }

    public function partnerRestore($id, Request $request){
       
        $partner = Partner::find($id);
        if (!$partner) {
            return response()->json(['error' => 'Partner not found'], 404);
        }
        $partner->archive = 1;
         $partner->save();
         return response()->json(['message' => 'Partner successfully updated', 'partner' =>$partner], 200);
    }

    public function accountDelete($id, Request $request){
       
        $program = User::find($id);
        if (!$program) {
            return response()->json(['error' => 'User not found'], 404);
        }
        $program->archive = 0;
         $program->save();
         return response()->json(['message' => 'User successfully updated', 'user' =>$program], 200);
    }

    public function accountRestore($id, Request $request){
       
        $program = User::find($id);
        if (!$program) {
            return response()->json(['error' => 'Account not found'], 404);
        }
        $program->archive = 1;
         $program->save();
         return response()->json(['message' => 'User successfully updated', 'user' =>$program], 200);
    }

    public function activePartnerDelete($id, Request $request){
       
        $partner = Partner::find($id);
        if (!$partner) {
            return response()->json(['error' => 'Partner not found'], 404);
        }
        $partner->archive = 0;
         $partner->save();
         return response()->json(['message' => 'Partner successfully updated', 'partner' =>$partner], 200);
    }

    private function generateVerificationCode()
    {
        $code = rand(100000, 999999);
        return strval($code);
    }

    public function sendEmail(Request $request,$email){
        $user = new User;
        $userid=User::where('email',$email)->get()->first();
        
        $code=$this->generateVerificationCode();
        // $expires_at = now('Asia/Manila')->addMinutes(5);
        // Verify::create([
        //     'user_id' => $userid->id,
        //     'v_code' => $code,
        //     'expired' => $expires_at 
        // ]);

        $userid->notify(new signUpEmailVerify($code));

        return response()->json(['message' => 'One Time Pin Succesfully send!',
        'Data' => $email,
        'user'=>$userid,
        'code'=>$code], 200);
    }

    public function verify(Request $request,$otp,$code){
        if ($otp == $code) {
            
            return response()->json(['message' => 'One Time Pin Match!!',
            'OTP' => $otp,
            'codeStorage' =>$code,
            'success' => true], 200);
        }
        else{
            return response()->json(['error' => 'Incorrect OTP','codeStorage' => $code,'success' => false]);
        } 
    }

    public function restPass($id, Request $request){
      
        $user = User::find($id);
        if (!$user) {
            return response()->json(['error' => 'User not found','success' => false], 404);
        }
        $user->password = Hash::make('admin123');
         $user->save();
         return response()->json(['message' => 'Password reset successfully','success' => true], 200);
    }

    public function changePass($id, Request $request){

        $validatedData = $request->validate([
            'password' => 'required|string|min:8|confirmed',
        ]);
        
        $user = User::find($id);
        if (!$user) {
            return response()->json(['error' => 'User not found'], 404);
        }
        $user->password = Hash::make($request->password);
        $user->status = 'approved';
         $user->save();
         return response()->json(['message' => 'Password updated successfully','success' => true], 200);
    }
    
}